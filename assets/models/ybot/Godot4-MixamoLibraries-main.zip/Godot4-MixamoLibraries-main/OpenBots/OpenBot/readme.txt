Import the FBX into your project.
Delete the OpenBotMesh
Resize the open bones to match your character mesh.
Parent the bones to your with automatic weights.
(Weight paint to fix issues as needed.)
Export to your preferred Godot format

Reimport into Godot and use the OpenBot-BoneMap.Res
Now your can use these open animation libraries with your humaniod characters.
(This humanoid skeleton in Godot is compatible with Mixamo libraries imported with the Mixamo Bone Map)

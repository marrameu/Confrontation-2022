Import the FBX into your project.
Delete the OpenDog mesh
Resize the open bones to match your canine model.
Parent the bones to your with automatic weights.
(Weight paint to fix issues as needed.)
Export to your preferred Godot format

Reimport into Godot and use the OpenDog-BoneMap.Res
Now your can use these open animation libraries with your canine characters.

You can also aid in making dog aniamtions using the .blend file. Opendog's rig was built from this project:
https://github.com/SAM-tak/BlenderGameRig
